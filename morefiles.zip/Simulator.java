public class Simulator  extends Thread {
    public World world;
    public Bug bug ;
    public Cell cell;
    public Map map;
    public static void init(){};
    public static void loadBugBrain(){};
    public static void increamentCount(){};
    public static void score(){};
    public  static void executeNextBugInstruction() {};
}
