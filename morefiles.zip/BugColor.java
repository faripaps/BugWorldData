
public enum BugColor {
    BLACK,
    RED
}
